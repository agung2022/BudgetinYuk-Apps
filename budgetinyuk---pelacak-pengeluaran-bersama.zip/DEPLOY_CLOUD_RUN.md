# 🚀 Panduan Deploy BudgetinYuk ke Google Cloud Run (GCP)

Aplikasi **BudgetinYuk** telah dikonfigurasi sepenuhnya agar siap dideploy ke **Google Cloud Run** di akun GCP pilihan Anda.

Kami telah membuat:
1. `Dockerfile`: Konfigurasi multi-stage build yang sangat aman dan terisolasi.
2. `server.js`: Server web Node.js murni (*dependency-free*) yang hemat memori, super cepat menyala, aman, dan kompatibel penuh dengan sistem Port injeksi dinamis milik GCP.
3. `.dockerignore`: Menjaga kecepatan *upload* kode sumber hanya ke komponen yang diperlukan.

Berikut adalah langkah lengkap untuk mendeploy aplikasi ini ke akun Google Cloud Platform yang baru:

---

## 🛠️ Langkah Eksport Kode & Persiapan
Sebelum memulai, Anda bisa mengunduh kode aplikasi ini:
1. Di AI Studio, buka menu **Settings** (ikon Gigi di pojok bawah/atas).
2. Pilih **Export as ZIP** untuk mengunduh seluruh berkas proyek ke komputer lokal Anda.
3. Ekstrak ZIP tersebut di komputer Anda dan buka terminal di folder tersebut.

---

## 💻 Langkah Deployment ke Google Cloud Platform

### Langkah 1: Pasang Google Cloud CLI
Pastikan komputer lokal Anda sudah terpasang **gcloud CLI**. Jika belum:
* Ikuti petunjuk resmi: [https://cloud.google.com/sdk/docs/install](https://cloud.google.com/sdk/docs/install)

### Langkah 2: Login ke Akun GCP Tujuan
Buka terminal di komputer Anda, lalu jalankan perintah berikut untuk login ke akun GCP baru Anda:
```bash
gcloud auth login
```
Jendela browser baru akan terbuka. Masuk menggunakan akun Google Anda yang memiliki akses GCP tujuan.

### Langkah 3: Tetapkan Project ID GCP Aktif
Tentukan project ID tempat Anda ingin mendeploy aplikasi ini. Jalankan:
```bash
# Ganti 'PROJECT_ID_ANDA' dengan ID proyek Google Cloud Anda
gcloud config set project PROJECT_ID_ANDA
```

### Langkah 4: Aktifkan API Layanan yang Diperlukan
Layanan Cloud Run membutuhkan beberapa API bawaan GCP agar aktif terlebih dahulu. Jalankan baris perintah ini:
```bash
gcloud services enable run.googleapis.com \
                       cloudbuild.googleapis.com \
                       artifactregistry.googleapis.com
```

### Langkah 5: Deploy Instan Ke Cloud Run (Disarankan)
Google Cloud memiliki fitur deploy instan yang sangat efisien lewat satu baris perintah. Anda tidak perlu membangun Docker secara manual; letakkan tugas pembangunan itu di server Google Cloud Build dengan menjalankan:

```bash
gcloud run deploy budgetinyuk \
    --source . \
    --region asia-southeast1 \
    --allow-unauthenticated
```

#### 🔎 Apa yang dilakukan perintah di atas?
1. `--source .`: Mendeteksi `Dockerfile` lokal kita secara otomatis, mengemas kode, lalu mengirimkannya ke **Cloud Build**.
2. **Cloud Build**: Membangun Docker Image dengan kinerja server GCP berkecepatan tinggi, lalu menyimpannya di **Artifact Registry** Anda sendiri secara gratis.
3. **Cloud Run**: Meluncurkan kontainer baru tersebut di region `asia-southeast1` (Jakarta/Singapura).
4. `--allow-unauthenticated`: Membuat URL aplikasi Anda dapat diakses publik oleh siapa saja secara web terbuka.

---

## 🎉 Hasil Akhir
Setelah perintah deploy selesai, terminal akan menampilkan URL resmi aplikasi Anda:
```text
Service [budgetinyuk] revision [budgetinyuk-00001-xxx] has been deployed and is serving 100% of traffic.
Service URL: https://budgetinyuk-xxxxxx-as.a.run.app
```
Buka tautan (Service URL) tersebut di browser Anda untuk melihat aplikasi **BudgetinYuk** yang kini aktif dan aman berjalan sepenuhnya di infrastruktur cloud global Anda!
